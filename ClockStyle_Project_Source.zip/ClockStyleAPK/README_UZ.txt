CLOCK STYLE — Android bosh ekran vidjeti

Ushbu loyiha rasmga o'xshash mustaqil Android vidjetining manba kodi.
Vidjet qora fon, yuqorida sana/batareya/hafta kuni va markazda katta kulrang soatni ko'rsatadi.

APK yaratish:
1. Kompyuterga Android Studio (Giraffe yoki yangiroq) o'rnating.
2. Android Studio'da ushbu papkani Open orqali oching.
3. Gradle sync tugashini kuting.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) ni tanlang.
5. APK app/build/outputs/apk/debug/app-debug.apk ichida hosil bo'ladi.
6. APK'ni telefonga yuborib o'rnating. So'ng bosh ekranda bo'sh joyni bosib turing > Widgets > Clock Style.

Izoh: Bu muhitda Android SDK/Gradle build vositalari mavjud emas, shu sababli bu yerning o'zida
APK binar faylini kompilyatsiya qilib tekshirish imkoni bo'lmadi. Loyiha Android Studio orqali build
qilinishi uchun tayyorlandi. Sana va soat TextClock orqali avtomatik yangilanadi; batareya foizi
vidjet yangilanganda yangilanadi.
